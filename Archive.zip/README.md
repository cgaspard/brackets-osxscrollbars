# brackets-osxscrollbar

CSS that makes the scrollbars look like the native OSx Scrollbars